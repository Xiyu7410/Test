## ✨ Website ucapan ulang tahun

[demo](https://hbd-jubed.netlify.app/)

## 🚀 Quick start

1. **Clone Repo**

   ```bash
   # clone repo dengan git command berikut
   $ git clone https://github.com/aafrzl/ucapan-ultah.git

   # masuk ke folder project
   $ cd ucapan-ultah

   # Buka di text editor kesayangan
   $ code .
   ```

2. **Buka dengan Live Server**

3. **Deploy ke Netlify**
   Deploy dengan Netlify drag and drop folder project ke Netlify [Netlify](https://www.netlify.com/)
